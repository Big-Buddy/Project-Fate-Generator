//NOT YET FULLY IMPLEMENTED
//function resolveConflicts

//list of dummy course JSON objects
var courses =
        [
            {
                "courseName": "Object Oriented Programming 1", "courseCode": "comp248", "credits": 4,
                "prerequisites": [], "corequisites": [], "priority": 0, "lectureSections":
                [
                    {
                        "semester": "fall", "lectureCode": "A", "lectureDays": "--W-F--",
                        "lectureStart": 1800, "lectureEnd": 2000, "tutorialSections":
                        [
                            {
                                "tutorialCode": "AA", "tutorialDays": "---J---",
                                "tutorialStart": 1400, "tutorialEnd": 1500
                            },
                            {
                                "tutorialCode": "AB", "tutorialDays": "--W----",
                                "tutorialStart": 1400, "tutorialEnd": 1500
                            },
                            {
                                "tutorialCode": "AC", "tutorialDays": "-T-----",
                                "tutorialStart": 1500, "tutorialEnd": 1600
                            }
                        ]
                        , "labSections":
                        [
                        ]
                    },
                    {
                        "semester": "fall", "lectureCode": "B", "lectureDays": "M-W----",
                        "lectureStart": 1800, "lectureEnd": 2000, "tutorialSections":
                        [
                            {
                                "tutorialCode": "BA", "tutorialDays": "----F--",
                                "tutorialStart": 1400, "tutorialEnd": 1500
                            },
                            {
                                "tutorialCode": "BB", "tutorialDays": "--W----",
                                "tutorialStart": 1000, "tutorialEnd": 1100
                            },
                            {
                                "tutorialCode": "BC", "tutorialDays": "M------",
                                "tutorialStart": 900, "tutorialEnd": 1000
                            }
                        ]
                        , "labSections":
                        [
                        ]
                    },
                    {
                        "semester": "fall", "lectureCode": "C", "lectureDays": "--W-F--",
                        "lectureStart": 1300, "lectureEnd": 1500, "tutorialSections":
                        [
                            {
                                "tutorialCode": "CA", "tutorialDays": "-T-----",
                                "tutorialStart": 900, "tutorialEnd": 1000
                            },
                            {
                                "tutorialCode": "CB", "tutorialDays": "-T-----",
                                "tutorialStart": 1300, "tutorialEnd": 1200
                            },
                            {
                                "tutorialCode": "CC", "tutorialDays": "-T-----",
                                "tutorialStart": 1700, "tutorialEnd": 1800
                            }
                        ]
                        , "labSections":
                        [
                        ]
                    }
                ]
            },
            {
                "courseName": "Mathematics for Computer Science", "courseCode": "comp232", "credits": 3,
                "prerequisites": [], "corequisites": [], "priority": 3, "lectureSections":
                [
                    {
                        "semester": "winter", "lectureCode": "A", "lectureDays": "M------",
                        "lectureStart": 900, "lectureEnd": 1200, "tutorialSections":
                        [
                            {
                                "tutorialCode": "AA", "tutorialDays": "M------",
                                "tutorialStart": 1300, "tutorialEnd": 1400
                            },
                            {
                                "tutorialCode": "AB", "tutorialDays": "M------",
                                "tutorialStart": 1600, "tutorialEnd": 1700
                            },
                            {
                                "tutorialCode": "AC", "tutorialDays": "----F--",
                                "tutorialStart": 2000, "tutorialEnd": 2200
                            }
                        ]
                        , "labSections":
                        [
                        ]
                    },
                    {
                        "semester": "fall", "lectureCode": "B", "lectureDays": "-T-J---",
                        "lectureStart": 1800, "lectureEnd": 2000, "tutorialSections":
                        [
                            {
                                "tutorialCode": "BA", "tutorialDays": "-T-----",
                                "tutorialStart": 1600, "tutorialEnd": 1700
                            },
                            {
                                "tutorialCode": "BB", "tutorialDays": "-T-----",
                                "tutorialStart": 1000, "tutorialEnd": 1100
                            },
                            {
                                "tutorialCode": "BC", "tutorialDays": "M------",
                                "tutorialStart": 1700, "tutorialEnd": 1900
                            }
                        ]
                        , "labSections":
                        [
                        ]
                    },
                    {
                        "semester": "fall", "lectureCode": "C", "lectureDays": "-T-J---",
                        "lectureStart": 1300, "lectureEnd": 1500, "tutorialSections":
                        [
                            {
                                "tutorialCode": "CA", "tutorialDays": "-T-----",
                                "tutorialStart": 1600, "tutorialEnd": 1700
                            },
                            {
                                "tutorialCode": "CB", "tutorialDays": "---J---",
                                "tutorialStart": 1600, "tutorialEnd": 1700
                            },
                            {
                                "tutorialCode": "CC", "tutorialDays": "---J---",
                                "tutorialStart": 1800, "tutorialEnd": 1900
                            }
                        ]
                        , "labSections":
                        [
                        ]
                    }
                ]
            },
            {
                "courseName": "Bullshit", "courseCode": "comp348", "credits": 3,
                "prerequisites": [], "corequisites": [], "priority": 4, "lectureSections":
                [
                    {
                        "semester": "fall", "lectureCode": "A", "lectureDays": "M------",
                        "lectureStart": 900, "lectureEnd": 1200, "tutorialSections":
                        [
                            {
                                "tutorialCode": "AA", "tutorialDays": "M------",
                                "tutorialStart": 1300, "tutorialEnd": 1400
                            },
                            {
                                "tutorialCode": "AB", "tutorialDays": "M------",
                                "tutorialStart": 1600, "tutorialEnd": 1700
                            },
                            {
                                "tutorialCode": "AC", "tutorialDays": "----F--",
                                "tutorialStart": 2000, "tutorialEnd": 2200
                            }
                        ]
                        , "labSections":
                        [
                        ]
                    },
                    {
                        "semester": "fall", "lectureCode": "B", "lectureDays": "-T-J---",
                        "lectureStart": 1800, "lectureEnd": 2000, "tutorialSections":
                        [
                            {
                                "tutorialCode": "BA", "tutorialDays": "-T-----",
                                "tutorialStart": 1600, "tutorialEnd": 1700
                            },
                            {
                                "tutorialCode": "BB", "tutorialDays": "--W----",
                                "tutorialStart": 1000, "tutorialEnd": 1100
                            },
                            {
                                "tutorialCode": "BC", "tutorialDays": "M------",
                                "tutorialStart": 1700, "tutorialEnd": 1900
                            }
                        ]
                        , "labSections":
                        [
                        ]
                    },
                    {
                        "semester": "fall", "lectureCode": "C", "lectureDays": "-T-J---",
                        "lectureStart": 1300, "lectureEnd": 1500, "tutorialSections":
                        [
                            {
                                "tutorialCode": "CA", "tutorialDays": "-T-----",
                                "tutorialStart": 1600, "tutorialEnd": 1700
                            },
                            {
                                "tutorialCode": "CB", "tutorialDays": "---J---",
                                "tutorialStart": 1600, "tutorialEnd": 1700
                            },
                            {
                                "tutorialCode": "CC", "tutorialDays": "---J---",
                                "tutorialStart": 1800, "tutorialEnd": 1900
                            }
                        ]
                        , "labSections":
                        [
                        ]
                    }
                ]
            },
            {
                "courseName": "Bullshit", "courseCode": "soen341", "credits": 3,
                "prerequisites": [], "corequisites": [], "priority": 1, "lectureSections":
                [
                    {
                        "semester": "winter", "lectureCode": "A", "lectureDays": "M------",
                        "lectureStart": 900, "lectureEnd": 1200, "tutorialSections":
                        [
                            {
                                "tutorialCode": "AA", "tutorialDays": "M------",
                                "tutorialStart": 1300, "tutorialEnd": 1400
                            },
                            {
                                "tutorialCode": "AB", "tutorialDays": "M------",
                                "tutorialStart": 1600, "tutorialEnd": 1700
                            },
                            {
                                "tutorialCode": "AC", "tutorialDays": "----F--",
                                "tutorialStart": 2000, "tutorialEnd": 2200
                            }
                        ]
                        , "labSections":
                        [
                        ]
                    },
                    {
                        "semester": "winter", "lectureCode": "B", "lectureDays": "-T-J---",
                        "lectureStart": 1800, "lectureEnd": 2000, "tutorialSections":
                        [
                            {
                                "tutorialCode": "BA", "tutorialDays": "-T-----",
                                "tutorialStart": 1600, "tutorialEnd": 1700
                            },
                            {
                                "tutorialCode": "BB", "tutorialDays": "--W----",
                                "tutorialStart": 1000, "tutorialEnd": 1100
                            },
                            {
                                "tutorialCode": "BC", "tutorialDays": "M------",
                                "tutorialStart": 1700, "tutorialEnd": 1900
                            }
                        ]
                        , "labSections":
                        [
                        ]
                    },
                    {
                        "semester": "winter", "lectureCode": "C", "lectureDays": "-T-J---",
                        "lectureStart": 1300, "lectureEnd": 1500, "tutorialSections":
                        [
                            {
                                "tutorialCode": "CA", "tutorialDays": "-T-----",
                                "tutorialStart": 1600, "tutorialEnd": 1700
                            },
                            {
                                "tutorialCode": "CB", "tutorialDays": "---J---",
                                "tutorialStart": 1600, "tutorialEnd": 1700
                            },
                            {
                                "tutorialCode": "CC", "tutorialDays": "---J---",
                                "tutorialStart": 1800, "tutorialEnd": 1900
                            }
                        ]
                        , "labSections":
                        [
                        ]
                    }
                ]
            },
            {
                "courseName": "Bullshit", "courseCode": "soen228", "credits": 3,
                "prerequisites": [], "corequisites": [], "priority": 2, "lectureSections":
                [
                    {
                        "semester": "fall", "lectureCode": "A", "lectureDays": "M------",
                        "lectureStart": 900, "lectureEnd": 1200, "tutorialSections":
                        [
                            {
                                "tutorialCode": "AA", "tutorialDays": "M------",
                                "tutorialStart": 1300, "tutorialEnd": 1400
                            },
                            {
                                "tutorialCode": "AB", "tutorialDays": "M------",
                                "tutorialStart": 1600, "tutorialEnd": 1700
                            },
                            {
                                "tutorialCode": "AC", "tutorialDays": "M------",
                                "tutorialStart": 2000, "tutorialEnd": 2200
                            }
                        ]
                        , "labSections":
                        [
                        ]
                    },
                    {
                        "semester": "fall", "lectureCode": "B", "lectureDays": "-T-J---",
                        "lectureStart": 1800, "lectureEnd": 2000, "tutorialSections":
                        [
                            {
                                "tutorialCode": "BA", "tutorialDays": "-T-----",
                                "tutorialStart": 1600, "tutorialEnd": 1700
                            },
                            {
                                "tutorialCode": "BB", "tutorialDays": "--W----",
                                "tutorialStart": 1000, "tutorialEnd": 1100
                            },
                            {
                                "tutorialCode": "BC", "tutorialDays": "M------",
                                "tutorialStart": 1700, "tutorialEnd": 1900
                            }
                        ]
                        , "labSections":
                        [
                        ]
                    },
                    {
                        "semester": "fall", "lectureCode": "C", "lectureDays": "-T-J---",
                        "lectureStart": 1300, "lectureEnd": 1500, "tutorialSections":
                        [
                            {
                                "tutorialCode": "CA", "tutorialDays": "-T-----",
                                "tutorialStart": 1600, "tutorialEnd": 1700
                            },
                            {
                                "tutorialCode": "CB", "tutorialDays": "---J---",
                                "tutorialStart": 1600, "tutorialEnd": 1700
                            },
                            {
                                "tutorialCode": "CC", "tutorialDays": "---J---",
                                "tutorialStart": 1800, "tutorialEnd": 1900
                            }
                        ]
                        , "labSections":
                        [
                        ]
                    }
                ]
            },
            {
                "courseName": "Bullshit", "courseCode": "elec275", "credits": 3,
                "prerequisites": [], "corequisites": [], "priority": 8, "lectureSections":
                [
                    {
                        "semester": "fall", "lectureCode": "A", "lectureDays": "M------",
                        "lectureStart": 900, "lectureEnd": 1200, "tutorialSections":
                        [
                            {
                                "tutorialCode": "AA", "tutorialDays": "M------",
                                "tutorialStart": 1300, "tutorialEnd": 1400
                            },
                            {
                                "tutorialCode": "AB", "tutorialDays": "M------",
                                "tutorialStart": 1600, "tutorialEnd": 1700
                            },
                            {
                                "tutorialCode": "AC", "tutorialDays": "----F--",
                                "tutorialStart": 2000, "tutorialEnd": 2200
                            }
                        ]
                        , "labSections":
                        [
                            {
                                "labCode": "AAA", "labDays": "-T-----",
                                "labStart": 1600, "labEnd": 1700
                            },
                            {
                                "labCode": "AAB", "labDays": "---J---",
                                "labStart": 1600, "labEnd": 1700
                            },
                            {
                                "labCode": "AAC", "labDays": "---J---",
                                "labStart": 1800, "labEnd": 1900
                            }
                        ]
                    },
                    {
                        "semester": "fall", "lectureCode": "B", "lectureDays": "-T-J---",
                        "lectureStart": 1800, "lectureEnd": 2000, "tutorialSections":
                        [
                            {
                                "tutorialCode": "BA", "tutorialDays": "-T-----",
                                "tutorialStart": 1600, "tutorialEnd": 1700
                            },
                            {
                                "tutorialCode": "BB", "tutorialDays": "--W----",
                                "tutorialStart": 1000, "tutorialEnd": 1100
                            },
                            {
                                "tutorialCode": "BC", "tutorialDays": "M------",
                                "tutorialStart": 1700, "tutorialEnd": 1900
                            }
                        ]
                        , "labSections":
                        [
                            {
                                "labCode": "BBA", "labDays": "-T-----",
                                "labStart": 1600, "labEnd": 1700
                            },
                            {
                                "labCode": "BBB", "labDays": "---J---",
                                "labStart": 1600, "labEnd": 1700
                            },
                            {
                                "labCode": "BBC", "labDays": "---J---",
                                "labStart": 1800, "labEnd": 1900
                            }
                        ]
                    },
                    {
                        "semester": "fall", "lectureCode": "C", "lectureDays": "-T-J---",
                        "lectureStart": 1300, "lectureEnd": 1500, "tutorialSections":
                        [
                            {
                                "tutorialCode": "CA", "tutorialDays": "-T-----",
                                "tutorialStart": 1600, "tutorialEnd": 1700
                            },
                            {
                                "tutorialCode": "CB", "tutorialDays": "---J---",
                                "tutorialStart": 1600, "tutorialEnd": 1700
                            },
                            {
                                "tutorialCode": "CC", "tutorialDays": "---J---",
                                "tutorialStart": 1800, "tutorialEnd": 1900
                            }
                        ]
                        , "labSections":
                        [
                            {
                                "labCode": "CCA", "labDays": "-T-----",
                                "labStart": 1600, "labEnd": 1700
                            },
                            {
                                "labCode": "CCB", "labDays": "---J---",
                                "labStart": 1600, "labEnd": 1700
                            },
                            {
                                "labCode": "CCC", "labDays": "---J---",
                                "labStart": 1800, "labEnd": 1900
                            }
                        ]
                    }
                ]
            },
            {
                "courseName": "Object Oriented Programming 2", "courseCode": "comp249", "credits": 3,
                "prerequisites": ["comp248"], "corequisites": [], "priority": 2, "lectureSections":
                [
                    {
                        "semester": "fall", "lectureCode": "A", "lectureDays": "M------",
                        "lectureStart": 900, "lectureEnd": 1200, "tutorialSections":
                        [
                            {
                                "tutorialCode": "AA", "tutorialDays": "M------",
                                "tutorialStart": 1300, "tutorialEnd": 1400
                            },
                            {
                                "tutorialCode": "AB", "tutorialDays": "----F--",
                                "tutorialStart": 1600, "tutorialEnd": 1700
                            },
                            {
                                "tutorialCode": "AC", "tutorialDays": "----F--",
                                "tutorialStart": 2000, "tutorialEnd": 2200
                            }
                        ]
                        , "labSections":
                        [
                        ]
                    },
                    {
                        "semester": "fall", "lectureCode": "B", "lectureDays": "-T-J---",
                        "lectureStart": 1800, "lectureEnd": 2000, "tutorialSections":
                        [
                            {
                                "tutorialCode": "BA", "tutorialDays": "-T-----",
                                "tutorialStart": 1600, "tutorialEnd": 1700
                            },
                            {
                                "tutorialCode": "BB", "tutorialDays": "--W----",
                                "tutorialStart": 1000, "tutorialEnd": 1100
                            },
                            {
                                "tutorialCode": "BC", "tutorialDays": "M------",
                                "tutorialStart": 1700, "tutorialEnd": 1900
                            }
                        ]
                        , "labSections":
                        [
                        ]
                    },
                    {
                        "semester": "fall", "lectureCode": "C", "lectureDays": "M-W----",
                        "lectureStart": 1300, "lectureEnd": 1500, "tutorialSections":
                        [
                            {
                                "tutorialCode": "CA", "tutorialDays": "M------",
                                "tutorialStart": 1600, "tutorialEnd": 1700
                            },
                            {
                                "tutorialCode": "CB", "tutorialDays": "--W----",
                                "tutorialStart": 1600, "tutorialEnd": 1700
                            },
                            {
                                "tutorialCode": "CC", "tutorialDays": "----F--",
                                "tutorialStart": 1800, "tutorialEnd": 1900
                            }
                        ]
                        , "labSections":
                        [
                        ]
                    }
                ]
            },
            {
                "courseName": "Bullshit", "courseCode": "engr201", "credits": 3,
                "prerequisites": [], "corequisites": [], "priority": 7, "lectureSections":
                [
                    {
                        "semester": "fall", "lectureCode": "A", "lectureDays": "M------",
                        "lectureStart": 900, "lectureEnd": 1200, "tutorialSections":
                        [
                            {
                                "tutorialCode": "AA", "tutorialDays": "-T-----",
                                "tutorialStart": 1300, "tutorialEnd": 1400
                            },
                            {
                                "tutorialCode": "AB", "tutorialDays": "---J---",
                                "tutorialStart": 1600, "tutorialEnd": 1700
                            },
                            {
                                "tutorialCode": "AC", "tutorialDays": "----F--",
                                "tutorialStart": 2000, "tutorialEnd": 2200
                            }
                        ]
                        , "labSections":
                        [
                        ]
                    },
                    {
                        "semester": "fall", "lectureCode": "B", "lectureDays": "--W-F--",
                        "lectureStart": 1800, "lectureEnd": 2000, "tutorialSections":
                        [
                            {
                                "tutorialCode": "BA", "tutorialDays": "--W----",
                                "tutorialStart": 1600, "tutorialEnd": 1700
                            },
                            {
                                "tutorialCode": "BB", "tutorialDays": "-T-----",
                                "tutorialStart": 1000, "tutorialEnd": 1100
                            },
                            {
                                "tutorialCode": "BC", "tutorialDays": "M------",
                                "tutorialStart": 1700, "tutorialEnd": 1900
                            }
                        ]
                        , "labSections":
                        [
                        ]
                    },
                    {
                        "semester": "fall", "lectureCode": "C", "lectureDays": "-T-J---",
                        "lectureStart": 1300, "lectureEnd": 1500, "tutorialSections":
                        [
                            {
                                "tutorialCode": "CA", "tutorialDays": "-T-----",
                                "tutorialStart": 1600, "tutorialEnd": 1700
                            },
                            {
                                "tutorialCode": "CB", "tutorialDays": "---J---",
                                "tutorialStart": 1600, "tutorialEnd": 1700
                            },
                            {
                                "tutorialCode": "CC", "tutorialDays": "M------",
                                "tutorialStart": 1800, "tutorialEnd": 1900
                            }
                        ]
                        , "labSections":
                        [
                        ]
                    }
                ]
            },
            {
                "courseName": "Bullshit", "courseCode": "comp401", "credits": 3,
                "prerequisites": [], "corequisites": [], "priority": 7, "lectureSections":
                [
                    {
                        "semester": "fall", "lectureCode": "A", "lectureDays": "M------",
                        "lectureStart": 900, "lectureEnd": 1200, "tutorialSections":
                        [
                            {
                                "tutorialCode": "AA", "tutorialDays": "M------",
                                "tutorialStart": 1300, "tutorialEnd": 1400
                            },
                            {
                                "tutorialCode": "AB", "tutorialDays": "M------",
                                "tutorialStart": 1600, "tutorialEnd": 1700
                            },
                            {
                                "tutorialCode": "AC", "tutorialDays": "----F--",
                                "tutorialStart": 2000, "tutorialEnd": 2200
                            }
                        ]
                        , "labSections":
                        [
                        ]
                    },
                    {
                        "semester": "fall", "lectureCode": "B", "lectureDays": "-T-J---",
                        "lectureStart": 1800, "lectureEnd": 2000, "tutorialSections":
                        [
                            {
                                "tutorialCode": "BA", "tutorialDays": "-T-----",
                                "tutorialStart": 1600, "tutorialEnd": 1700
                            },
                            {
                                "tutorialCode": "BB", "tutorialDays": "--W----",
                                "tutorialStart": 1000, "tutorialEnd": 1100
                            },
                            {
                                "tutorialCode": "BC", "tutorialDays": "M------",
                                "tutorialStart": 1700, "tutorialEnd": 1900
                            }
                        ]
                        , "labSections":
                        [
                        ]
                    },
                    {
                        "semester": "fall", "lectureCode": "C", "lectureDays": "----F--",
                        "lectureStart": 1300, "lectureEnd": 1500, "tutorialSections":
                        [
                            {
                                "tutorialCode": "CA", "tutorialDays": "-T-----",
                                "tutorialStart": 1600, "tutorialEnd": 1700
                            },
                            {
                                "tutorialCode": "CB", "tutorialDays": "----F--",
                                "tutorialStart": 1600, "tutorialEnd": 1700
                            },
                            {
                                "tutorialCode": "CC", "tutorialDays": "M------",
                                "tutorialStart": 1800, "tutorialEnd": 1900
                            }
                        ]
                        , "labSections":
                        [
                        ]
                    }
                ]
            },
            {
                "courseName": "Bullshit", "courseCode": "biol201", "credits": 3,
                "prerequisites": [], "corequisites": [], "priority": 7, "lectureSections":
                [
                    {
                        "semester": "fall", "lectureCode": "EC", "lectureDays": null,
                        "lectureStart": null, "lectureEnd": null, "tutorialSections":
                        [
                        ]
                        , "labSections":
                        [
                        ]
                    }
                ]
            }
        ];

//function implementations

//Takes as parameters the list of all required courses for the program
//and an emty list and populates it with thse courses
function createIncompleteList(courses, incompleteCourses)
{
    var i;
    
    for (i = 0; i < courses.length; i++)
    {
       incompleteCourses.push(courses[i]);
    }
    for (i = 0; i < incompleteCourses.length; i++)
    {
        document.write(incompleteCourses[i].courseCode + " ");
    }
    document.write("<br>");
    document.write("<br>");
}

//Takes as parameters the list of incomplete courses and
//the list of completed courses and removes those that have been completed
function removeCompletedCourses(incompleteCourses, completeCourses)
{
    var i;
    var j;
    
    for (i = 0; i < incompleteCourses.length; i++)
    {
        for (j = 0; j < completeCourses.length; j++)
        {
            if (incompleteCourses[i].courseCode == completeCourses[j])
            {
                incompleteCourses.splice(i, 1);
                i--;
                break;
            }
        }
    }
    for (i = 0; i < incompleteCourses.length; i++)
    {
        document.write(incompleteCourses[i].courseCode + " ");
    }
    document.write("<br>");
    document.write("<br>");
}

//Takes as parameters the current semester the list of all courses and
//an empty list and populates it with courses that are offered in the same term
function addToPotentialList(term, courses, potentialCourses)
{
    for (i = 0; i < courses.length; i++)
    {
        for (j = 0; j < courses[i].lectureSections.length; j++)
        {
            if (courses[i].lectureSections[j].semester == term)
            {
                potentialCourses.push(courses[i]);
                break;
            }
        }
    }
    for (i = 0; i < potentialCourses.length; i++)
    {
        document.write(potentialCourses[i].courseCode + " ");
    }
    document.write("<br>");
    document.write("<br>");
}


//Takes as parameters the list of all incomplete courses and
//the list of courses offered in the semester and removes all 400 level
//courses if there are any incomplete 200 level courses
function remove400LevelCourses(potentialCourses, incompleteCourses)
{
    var i;
    var remove400 = false;

    for (i = 0; i < incompleteCourses.length; i++)
    {
        if (incompleteCourses[i].courseCode[4] == '2')
        {
            remove400 = true;
            break;
        }
    }
    if (remove400 == true)
    {
        for (i = 0; i < potentialCourses.length; i++)
        {
            if (potentialCourses[i].courseCode[4] == '4')
            {
                potentialCourses.splice(i, 1)
                i--;
            }
        }
    }
    for (i = 0; i < potentialCourses.length; i++)
    {
        document.write(potentialCourses[i].courseCode + " ");
    }
    document.write("<br>");
    document.write("<br>");
}

//Takes as parameters the list of courses offered in the semester and
//the list of completed courses and removes any courses that have prerequisites
//if they are not yet completed
function removeIncompletePrerequisiteCourses(potentialCourses, completeCourses)
{
    var i;
    var j;
    var k;
    var completedPrerequisites = 0;
    
    for (i = 0; i < potentialCourses.length; i++)
    {
        for (j = 0; j < potentialCourses[i].prerequisites.length; j++)
        {
            for (k = 0; k < completeCourses.length; k++)
            {
                if(potentialCourses[i].prerequisites[j] == completeCourses[k])
                {
                    completedPrerequisites++;
                }
            }

            if(completedPrerequisites != potentialCourses[i].prerequisites.length)
            {
                potentialCourses.splice(i, 1)
                i--;
            }
        }
    }
    for (i = 0; i < potentialCourses.length; i++)
    {
        document.write(potentialCourses[i].courseCode + " ");
    }
    document.write("<br>");
    document.write("<br>");
}

//Takes as parameters the list of courses offered in the semester and
// an empty list and uses it to sort the courses by their priority
function sortPotentialList(potentialCourses, lowPriorityCourses)
{
    var i;
    var j;
    
    for (i = 0; i < potentialCourses.length; i++)
    {
        var currentLowIndex = 0;
        var currentLowPriority = potentialCourses[0].priority;
        
        for(j = 0; j < potentialCourses.length; j++)
        {
            if(potentialCourses[j].priority < currentLowPriority)
            {
                currentLowIndex = j;
                currentLowPriority = potentialCourses[j].priority;
            }
        }
        
        lowPriorityCourses.push(potentialCourses[currentLowIndex]);
        potentialCourses.splice(currentLowIndex, 1)
        i--; 
    }
    for (i = 0; i < lowPriorityCourses.length; i++)
    {
        potentialCourses.push(lowPriorityCourses[i])
        lowPriorityCourses.splice(lowPriorityCourses[i], 1);
        i--;
    }
    for (i = 0; i < potentialCourses.length; i++)
    {
        document.write(potentialCourses[i].courseCode + " ")
    }
    document.write("<br>");
    document.write("<br>");
}

//Takes as parameters the users preference for courses per semester,
//the list of courses for the semester,
//the list of courses offered in the semester and
//an empty list and adds the low priority courses to it and removes
//those from potential courses for the semester
//If the low priority course is an online course it is removed
//from the list of potential courses for the semester and added
//directly to the list of courses for the current semester
function selectCoursesForSemester(coursesPerSemester, semesterCourses, potentialCourses, lowPriorityCourses)
{
    var i;
    
    for (i = 0; i < potentialCourses.length - (coursesPerSemester - 1); i++)
    {
       lowPriorityCourses.push(potentialCourses[potentialCourses.length - 1]);
       potentialCourses.pop();
       i--;
    }
    if(lowPriorityCourses.length > 0)
    {    
        potentialCourses.push(lowPriorityCourses[0]);
        lowPriorityCourses.shift();
    }    
    if(potentialCourses[(potentialCourses.length - 1)].lectureSections[0].lectureCode == "EC")
    {
        semesterCourses.push(potentialCourses[potentialCourses.length - 1]);
        document.write(semesterCourses.length);
        potentialCourses.splice((potentialCourses.length - 1), 1);
    }     
    for (i = 0; i < potentialCourses.length; i++)
    {
        document.write(potentialCourses[i].courseCode + " ");
    }
    document.write("<br>");
    document.write("<br>");
}

//Takes as parameters the current semester and a list of courses offered in
//the semester and creates and returns an array with counters for the conflicts
//between sections of potential courses with all elements initialized to 0
function initializeConflictCounterForSections(term, potentialCourses)
{
    var i;
    var j;
    var k;
    var numLectureSections = 0;
    var termLectureSection = 0;;
    var createConfictArray = new Array(potentialCourses.length);
    
    for (i = 0; i < createConfictArray.length; i++)
    {
        createConfictArray[i] = new Array(3);
    }
    for (i = 0; i < potentialCourses.length; i++)
    {
       if(potentialCourses[i].lectureSections.lectureCode != "EC")
       {
            for (j = 0; j < potentialCourses[i].lectureSections.length; j++)
            {
                if(potentialCourses[i].lectureSections[j].semester == term)
                {
                    numLectureSections++;
                    termLectureSection = j;
                }
            }
        }
        if(potentialCourses[i].lectureSections.lectureCode != "EC")
        {
            createConfictArray[i][0] = new Array(numLectureSections);
            createConfictArray[i][1] = new Array(potentialCourses[i].lectureSections[termLectureSection].tutorialSections.length * numLectureSections)
            createConfictArray[i][2] = new Array(potentialCourses[i].lectureSections[termLectureSection].labSections.length * potentialCourses[i].lectureSections.length)
            numLectureSections = 0;
        }
        if(potentialCourses[i].lectureSections.lectureCode == "EC")
        {
            createConfictArray[i][0] = new Array(1);
            createConfictArray[i][1] = new Array(0)
            createConfictArray[i][2] = new Array(0)
        }
    }
    for (i = 0; i < createConfictArray.length; i++)
    {
        for (j = 0; j < createConfictArray[i].length; j++)
        {
            for (k = 0; k < createConfictArray[i][j].length; k++)
            {
                createConfictArray[i][j][k] = 0;
            }
        }
    }
    for (i = 0; i < createConfictArray.length; i++)
    {
        for (j = 0; j < createConfictArray[i].length; j++)
        {
            for (k = 0; k < createConfictArray[i][j].length; k++)
            {
                document.write(createConfictArray[i][j][k] + " ");
            }
            document.write("<br>");
        }
    }
    document.write("<br>");
    return createConfictArray;
}

//Takes as parameters the current semester, a list of courses offered in
//the semester and the list of conflicts for each section and tests for conflicts
//between sections while increment corresponding counters
function countTimeConflicts(term, potentialCourses, conflictCounterForSections)
{
    var a;
    var i;
    var j;
    var k;
    var l;
    var m;
    var n;
    var x;
    var y;
    var z;
    var termCourseSection1;
    var termCourseSection2;
    var invalidTermSections = 0;
    
    for (i = 0; i < potentialCourses.length; i++)
    {
        for (j = 0; j < potentialCourses.length; j++)
        {
            if(potentialCourses[i].courseCode != potentialCourses[j].courseCode)
            {
                for(a = 0; a < potentialCourses[i].lectureSections.length; a++)
                {
                    if(potentialCourses[i].lectureSections[a].semester == term)
                    {
                        termCourseSection1 = a;
                        break;
                    }
                }

                for(a = 0; a < potentialCourses[j].lectureSections.length; a++)
                {
                    if(potentialCourses[j].lectureSections[a].semester == term)
                    {
                        termCourseSection2 = a;
                        break;
                    }
                }
                
                //////////////////////////////////////////////////////////////
              
                for(k = 0; k < potentialCourses[i].lectureSections.length; k++)
                {
                    if(potentialCourses[i].lectureSections[k].semester != term)
                    {
                        invalidTermSections++;
                    }
                    if(potentialCourses[i].lectureSections[k].semester == term)
                    {
                        for(l = 0; l < potentialCourses[j].lectureSections.length; l++)
                        {
                            if(potentialCourses[j].lectureSections[l].semester == term)
                            {
                                for(z = 0; z < 7; z++)
                                {
                                    if((potentialCourses[i].lectureSections[k].lectureDays[z] == potentialCourses[j].lectureSections[l].lectureDays[z]) && (potentialCourses[i].lectureSections[k].lectureDays[z] != "-"))
                                    {
                                        if((potentialCourses[i].lectureSections[k].lectureEnd >= potentialCourses[j].lectureSections[l].lectureStart) && (potentialCourses[i].lectureSections[k].lectureEnd <= potentialCourses[j].lectureSections[l].lectureEnd))
                                        {
                                            conflictCounterForSections[i][0][k - invalidTermSections]++;
                                        }
                                        if((potentialCourses[j].lectureSections[l].lectureEnd >= potentialCourses[i].lectureSections[k].lectureStart) && (potentialCourses[j].lectureSections[l].lectureEnd <= potentialCourses[i].lectureSections[k].lectureEnd))
                                        {
                                            conflictCounterForSections[i][0][k - invalidTermSections]++;
                                        }
                                    }
                                }    
                            }
                        }
                    }
                }
                
                invalidTermSections = 0;
                
                if(potentialCourses[j].lectureSections[termCourseSection2].tutorialSections.length > 0)
                {
                    for(k = 0; k < potentialCourses[i].lectureSections.length; k++)
                    {
                        if(potentialCourses[i].lectureSections[k].semester != term)
                        {
                            invalidTermSections++;
                        }
                        if(potentialCourses[i].lectureSections[k].semester == term)
                        {
                            for(l = 0; l < potentialCourses[j].lectureSections.length; l++)
                            {
                                if(potentialCourses[j].lectureSections[l].semester == term)
                                {
                                    for(x = 0; x < potentialCourses[j].lectureSections[l].tutorialSections.length; x++)
                                    {
                                        for(z = 0; z < 7; z++)
                                        {
                                            if((potentialCourses[i].lectureSections[k].lectureDays[z] == potentialCourses[j].lectureSections[l].tutorialSections[x].tutorialDays[z]) && (potentialCourses[i].lectureSections[k].lectureDays[z] != "-"))
                                            {
                                                if((potentialCourses[i].lectureSections[k].lectureEnd >= potentialCourses[j].lectureSections[l].tutorialSections[x].tutorialStart) && (potentialCourses[i].lectureSections[k].lectureEnd <= potentialCourses[j].lectureSections[l].tutorialSections[x].tutorialEnd))
                                                {
                                                    conflictCounterForSections[i][0][k - invalidTermSections]++;
                                                }
                                                if((potentialCourses[j].lectureSections[l].tutorialSections[x].tutorialEnd >= potentialCourses[i].lectureSections[k].lectureStart) && (potentialCourses[j].lectureSections[l].tutorialSections[x].tutorialEnd <= potentialCourses[i].lectureSections[k].lectureEnd))
                                                {
                                                    conflictCounterForSections[i][0][k - invalidTermSections]++;
                                                }
                                            }
                                        } 
                                    }
                                }
                            }
                        }
                    }
                }
                
                invalidTermSections = 0;

                if(potentialCourses[j].lectureSections[termCourseSection2].labSections.length > 0)
                {
                    for(k = 0; k < potentialCourses[i].lectureSections.length; k++)
                    {
                        if(potentialCourses[i].lectureSections[k].semester != term)
                        {
                            invalidTermSections++;
                        }
                        if(potentialCourses[i].lectureSections[k].semester == term)
                        {
                            for(l = 0; l < potentialCourses[j].lectureSections.length; l++)
                            {
                                if(potentialCourses[j].lectureSections[l].semester == term)
                                {
                                    for(x = 0; x < potentialCourses[j].lectureSections[l].labSections.length; x++)
                                    {
                                        for(z = 0; z < 7; z++)
                                        {
                                            if((potentialCourses[i].lectureSections[k].lectureDays[z] == potentialCourses[j].lectureSections[l].labSections[x].labDays[z]) && (potentialCourses[i].lectureSections[k].lectureDays[z] != "-"))
                                            {
                                                if((potentialCourses[i].lectureSections[k].lectureEnd >= potentialCourses[j].lectureSections[l].labSections[x].labStart) && (potentialCourses[i].lectureSections[k].lectureEnd <= potentialCourses[j].lectureSections[l].labSections[x].labEnd))
                                                {
                                                    conflictCounterForSections[i][0][k - invalidTermSections]++;
                                                }
                                                if((potentialCourses[j].lectureSections[l].labSections[x].labEnd >= potentialCourses[i].lectureSections[k].lectureStart) && (potentialCourses[j].lectureSections[l].labSections[x].labEnd <= potentialCourses[i].lectureSections[k].lectureEnd))
                                                {
                                                    conflictCounterForSections[i][0][k - invalidTermSections]++;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                
                invalidTermSections = 0;
                
                //////////////////////////////////////////////////////////////////////////////////////

                if(potentialCourses[i].lectureSections[termCourseSection1].tutorialSections.length > 0)
                {
                    for(k = 0; k < potentialCourses[i].lectureSections.length; k++)
                    {
                        if(potentialCourses[i].lectureSections[k].semester != term)
                        {
                            invalidTermSections++;
                        }
                        if(potentialCourses[i].lectureSections[k].semester == term)
                        {
                            for(x = 0; x < potentialCourses[i].lectureSections[k].tutorialSections.length; x++)
                            {
                                for(l = 0; l < potentialCourses[j].lectureSections.length; l++)
                                {
                                    if(potentialCourses[j].lectureSections[l].semester == term)
                                    {
                                        for(z = 0; z < 7; z++)
                                        {
                                            if((potentialCourses[i].lectureSections[k].tutorialSections[x].tutorialDays[z] == potentialCourses[j].lectureSections[l].lectureDays[z])  && (potentialCourses[i].lectureSections[k].tutorialSections[x].tutorialDays[z] != "-"))
                                            {
                                                if((potentialCourses[i].lectureSections[k].tutorialSections[x].tutorialEnd >= potentialCourses[j].lectureSections[l].lectureStart) && (potentialCourses[i].lectureSections[k].tutorialSections[x].tutorialEnd <= potentialCourses[j].lectureSections[l].lectureEnd))
                                                {
                                                    conflictCounterForSections[i][1][x + ((k - invalidTermSections) * potentialCourses[i].lectureSections.length)]++;
                                                }
                                                if((potentialCourses[j].lectureSections[l].lectureEnd >= potentialCourses[i].lectureSections[k].tutorialSections[x].tutorialStart) && (potentialCourses[j].lectureSections[l].lectureEnd <= potentialCourses[i].lectureSections[k].tutorialSections[x].tutorialEnd))
                                                {
                                                    conflictCounterForSections[i][1][x + ((k - invalidTermSections) * potentialCourses[i].lectureSections.length)]++;
                                                }
                                            }
                                        
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                
                invalidTermSections = 0;

                if(potentialCourses[i].lectureSections[termCourseSection1].tutorialSections.length > 0)
                {
                    if(potentialCourses[j].lectureSections[termCourseSection2].tutorialSections.length > 0)
                    {
                        for(k = 0; k < potentialCourses[i].lectureSections.length; k++)
                        {
                            if(potentialCourses[i].lectureSections[k].semester != term)
                            {
                                invalidTermSections++;
                            }
                            if(potentialCourses[i].lectureSections[k].semester == term)
                            {
                                for(x = 0; x < potentialCourses[i].lectureSections[k].tutorialSections.length; x++)
                                {
                                    for(l = 0; l < potentialCourses[j].lectureSections.length; l++)
                                    {
                                        if(potentialCourses[j].lectureSections[l].semester == term)
                                        {
                                            for(y = 0; y < potentialCourses[j].lectureSections[l].tutorialSections.length; y++)
                                            {
                                                for(z = 0; z < 7; z++)
                                                {
                                                    if((potentialCourses[i].lectureSections[k].tutorialSections[x].tutorialDays[z] == potentialCourses[j].lectureSections[l].tutorialSections[y].tutorialDays[z]) && (potentialCourses[i].lectureSections[k].tutorialSections[x].tutorialDays[z] != "-"))
                                                    {
                                                        if((potentialCourses[i].lectureSections[k].tutorialSections[x].tutorialEnd >= potentialCourses[j].lectureSections[l].tutorialSections[y].tutorialStart) && (potentialCourses[i].lectureSections[k].tutorialSections[x].tutorialEnd <= potentialCourses[j].lectureSections[l].tutorialSections[y].tutorialEnd))
                                                        {
                                                            conflictCounterForSections[i][1][x + ((k - invalidTermSections) * potentialCourses[i].lectureSections.length)]++;
                                                        }
                                                        if((potentialCourses[j].lectureSections[l].tutorialSections[y].tutorialEnd >= potentialCourses[i].lectureSections[k].tutorialSections[x].tutorialStart) && (potentialCourses[j].lectureSections[l].tutorialSections[y].tutorialEnd <= potentialCourses[i].lectureSections[k].tutorialSections[x].tutorialEnd))
                                                        {
                                                            conflictCounterForSections[i][1][x + ((k - invalidTermSections) * potentialCourses[i].lectureSections.length)]++;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                
                invalidTermSections = 0;
                
                if(potentialCourses[i].lectureSections[termCourseSection1].tutorialSections.length > 0)
                {
                    if(potentialCourses[j].lectureSections[termCourseSection2].labSections.length > 0)
                    {
                        for(k = 0; k < potentialCourses[i].lectureSections.length; k++)
                        {
                            if(potentialCourses[i].lectureSections[k].semester != term)
                            {
                                invalidTermSections++;
                            }
                            if(potentialCourses[i].lectureSections[k].semester == term)
                            {
                                for(x = 0; x < potentialCourses[i].lectureSections[k].tutorialSections.length; x++)
                                {
                                    for(l = 0; l < potentialCourses[j].lectureSections.length; l++)
                                    {
                                        if(potentialCourses[j].lectureSections[l].semester == term)
                                        {
                                            for(y = 0; y < potentialCourses[j].lectureSections[l].labSections.length; y++)
                                            {
                                                for(z = 0; z < 7; z++)
                                                {
                                                    if((potentialCourses[i].lectureSections[k].tutorialSections[x].tutorialDays[z] == potentialCourses[j].lectureSections[l].labSections[y].labDays[z]) && (potentialCourses[i].lectureSections[k].tutorialSections[x].tutorialDays[z] != "-"))
                                                    {
                                                        if((potentialCourses[i].lectureSections[k].tutorialSections[x].tutorialEnd >= potentialCourses[j].lectureSections[l].labSections[y].labStart) && (potentialCourses[i].lectureSections[k].tutorialSections[x].tutorialEnd <= potentialCourses[j].lectureSections[l].labSections[y].labEnd))
                                                        {
                                                            conflictCounterForSections[i][1][x + ((k - invalidTermSections) * potentialCourses[i].lectureSections.length)]++;
                                                        }
                                                        if((potentialCourses[j].lectureSections[l].labSections[y].labEnd >= potentialCourses[i].lectureSections[k].tutorialSections[x].tutorialStart) && (potentialCourses[j].lectureSections[l].labSections[y].labEnd <= potentialCourses[i].lectureSections[k].tutorialSections[x].tutorialEnd))
                                                        {
                                                            conflictCounterForSections[i][1][x + ((k - invalidTermSections) * potentialCourses[i].lectureSections.length)]++;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                
                invalidTermSections = 0;
                
                /////////////////////////////////////////////////////////////////////////////////
               
                if(potentialCourses[i].lectureSections[termCourseSection1].labSections.length > 0)
                {
                    for(k = 0; k < potentialCourses[i].lectureSections.length; k++)
                    {
                        if(potentialCourses[i].lectureSections[k].semester != term)
                        {
                            invalidTermSections++;
                        }
                        if(potentialCourses[i].lectureSections[k].semester == term)
                        {
                            for(x = 0; x < potentialCourses[i].lectureSections[k].labSections.length; x++)
                            {
                                for(l = 0; l < potentialCourses[j].lectureSections.length; l++)
                                {
                                    if(potentialCourses[j].lectureSections[l].semester == term)
                                    {
                                        for(z = 0; z < 7; z++)
                                        {
                                            if((potentialCourses[i].lectureSections[k].labSections[x].labDays[z] == potentialCourses[j].lectureSections[l].lectureDays[z]) && (potentialCourses[i].lectureSections[k].labSections[x].labDays[z] != "-"))
                                            {
                                                if((potentialCourses[i].lectureSections[k].labSections[x].labEnd >= potentialCourses[j].lectureSections[l].lectureStart) && (potentialCourses[i].lectureSections[k].labSections[x].labEnd <= potentialCourses[j].lectureSections[l].lectureEnd))
                                                {
                                                    conflictCounterForSections[i][2][x + ((k - invalidTermSections) * potentialCourses[i].lectureSections.length)]++;
                                                }
                                                if((potentialCourses[j].lectureSections[l].lectureEnd >= potentialCourses[i].lectureSections[k].labSections[x].labStart) && (potentialCourses[j].lectureSections[l].lectureEnd <= potentialCourses[i].lectureSections[k].labSections[x].labEnd))
                                                {
                                                    conflictCounterForSections[i][2][x + ((k - invalidTermSections) * potentialCourses[i].lectureSections.length)]++;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                
                invalidTermSections = 0;
              
                if(potentialCourses[i].lectureSections[termCourseSection1].labSections.length > 0)
                {
                    if(potentialCourses[j].lectureSections[termCourseSection2].tutorialSections.length > 0)
                    {
                        for(k = 0; k < potentialCourses[i].lectureSections.length; k++)
                        {
                            if(potentialCourses[i].lectureSections[k].semester != term)
                            {
                                invalidTermSections++;
                            }
                            if(potentialCourses[i].lectureSections[k].semester == term)
                            {
                                for(x = 0; x < potentialCourses[i].lectureSections[k].labSections.length; x++)
                                {
                                    for(l = 0; l < potentialCourses[j].lectureSections.length; l++)
                                    {
                                        if(potentialCourses[j].lectureSections[l].semester == term)
                                        {
                                            for(y = 0; y < potentialCourses[j].lectureSections[l].tutorialSections.length; y++)
                                            {
                                               for(z = 0; z < 7; z++)
                                                {
                                                    if((potentialCourses[i].lectureSections[k].labSections[x].labDays[z] == potentialCourses[j].lectureSections[l].tutorialSections[y].tutorialDays[z]) && (potentialCourses[i].lectureSections[k].labSections[x].labDays[z] != "-"))
                                                    {
                                                        if((potentialCourses[i].lectureSections[k].labSections[x].labEnd >= potentialCourses[j].lectureSections[l].tutorialSections[y].tutorialStart) && (potentialCourses[i].lectureSections[k].labSections[x].labEnd <= potentialCourses[j].lectureSections[l].tutorialSections[y].tutorialEnd))
                                                        {
                                                            conflictCounterForSections[i][2][x + ((k - invalidTermSections) * potentialCourses[i].lectureSections.length)]++;
                                                        }
                                                        if((potentialCourses[j].lectureSections[l].tutorialSections[y].tutorialEnd >= potentialCourses[i].lectureSections[k].labSections[x].labStart) && (potentialCourses[j].lectureSections[l].tutorialSections[y].tutorialEnd <= potentialCourses[i].lectureSections[k].labSections[x].labEnd))
                                                        {
                                                            conflictCounterForSections[i][2][x + ((k - invalidTermSections) * potentialCourses[i].lectureSections.length)]++;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                
                invalidTermSections = 0;

                if(potentialCourses[i].lectureSections[termCourseSection1].labSections.length > 0)
                {
                    if(potentialCourses[j].lectureSections[termCourseSection2].labSections.length > 0)
                    {
                        for(k = 0; k < potentialCourses[i].lectureSections.length; k++)
                        {
                            if(potentialCourses[i].lectureSections[k].semester != term)
                            {
                                invalidTermSections++;
                            }
                            if(potentialCourses[i].lectureSections[k].semester == term)
                            {
                                for(x = 0; x < potentialCourses[i].lectureSections[k].labSections.length; x++)
                                {
                                    for(l = 0; l < potentialCourses[j].lectureSections.length; l++)
                                    {
                                        if(potentialCourses[j].lectureSections[l].semester == term)
                                        {
                                            for(y = 0; y < potentialCourses[j].lectureSections[l].labSections.length; y++)
                                            {
                                                for(z = 0; z < 7; z++)
                                                {
                                                    if((potentialCourses[i].lectureSections[k].labSections[x].labDays[z] == potentialCourses[j].lectureSections[l].labSections[y].labDays[z]) && (potentialCourses[i].lectureSections[k].labSections[x].labDays[z] != "-"))
                                                    {
                                                        if((potentialCourses[i].lectureSections[k].labSections[x].labEnd >= potentialCourses[j].lectureSections[l].labSections[y].labStart) && (potentialCourses[i].lectureSections[k].labSections[x].labEnd <= potentialCourses[j].lectureSections[l].labSections[y].labEnd))
                                                        {
                                                            conflictCounterForSections[i][2][x + ((k - invalidTermSections) * potentialCourses[i].lectureSections.length)]++;
                                                        }
                                                        if((potentialCourses[j].lectureSections[l].labSections[y].labEnd >= potentialCourses[i].lectureSections[k].labSections[x].labStart) && (potentialCourses[j].lectureSections[l].labSections[y].labEnd <= potentialCourses[i].lectureSections[k].labSections[x].labEnd))
                                                        {
                                                            conflictCounterForSections[i][2][x + ((k - invalidTermSections) * potentialCourses[i].lectureSections.length)]++;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    for (i = 0; i < conflictCounterForSections.length; i++)
    {
        for (j = 0; j < conflictCounterForSections[i].length; j++)
        {
            for (k = 0; k < conflictCounterForSections[i][j].length; k++)
            {
                document.write(conflictCounterForSections[i][j][k] + " ");
            }
            document.write("<br>");
        }
    }
    document.write("<br>");
}

//Takes as parameters the list of courses offered in the semester and
//the list of conflicts for each section and finds the sections
//with the least conflicts for each course and adds them to an empty list
function addLowestConflictSections(potentialCourses, conflictCounterForSections, potentialCourseSections)
{
    var i;
    var j;
    var lowestConflicts = 100
    var lowestConflictLectureIndex = 0;
    var lowestConflictTutorialIndex = 0;
    var lowestConflictLabIndex = 0;
    
    for (i = 0; i < potentialCourses.length; i++)
    {
        for(j = 0; j < potentialCourses[i].lectureSections.length; j++)
        {
            if(conflictCounterForSections[i][0][j] < lowestConflicts)
            {
                lowestConflicts = conflictCounterForSections[i][0][j];
                lowestConflictLectureIndex = j;
            }
        }
        
        lowestConflicts = 100

        for(j = 0; j < potentialCourses[i].lectureSections[lowestConflictLectureIndex].tutorialSections.length; j++)
        {
            if(conflictCounterForSections[i][1][j + (lowestConflictLectureIndex * potentialCourses[i].lectureSections.length)] < lowestConflicts)
            {
                lowestConflicts = conflictCounterForSections[i][1][j];
                lowestConflictTutorialIndex = j;
            }
        }
        
        lowestConflicts = 100
        
        for(j = 0; j < potentialCourses[i].lectureSections[lowestConflictLectureIndex].labSections.length; j++)
        {
            if(conflictCounterForSections[i][2][j + (lowestConflictTutorialIndex * potentialCourses[i].lectureSections.length)] < lowestConflicts)
            {
                lowestConflicts = conflictCounterForSections[i][2][j];
                lowestConflictLabIndex = j;
            }
        }
        
        document.write(lowestConflictLectureIndex + "<br>");
        
        if(potentialCourses[i].lectureSections[lowestConflictLectureIndex].tutorialSections.length > 0)
        {
            document.write(lowestConflictTutorialIndex + "<br>");
        }
        if(potentialCourses[i].lectureSections[lowestConflictLectureIndex].labSections.length > 0)
        {
            document.write(lowestConflictLabIndex + "<br>");
        }
        
        potentialCourseSections.push(potentialCourses[i]);
        
        for(j = 0; j < potentialCourseSections[i].lectureSections.length; j++)
        {
            if(j != lowestConflictLectureIndex)
            {
                potentialCourseSections[i].lectureSections.splice(j, 1);
                lowestConflictLectureIndex--;
                j--;
            }
        }
        for(j = 0; j < potentialCourseSections[i].lectureSections[0].tutorialSections.length; j++)
        {
            if(j != lowestConflictTutorialIndex)
            {
                potentialCourseSections[i].lectureSections[0].tutorialSections.splice(j, 1);
                lowestConflictTutorialIndex--;
                j--;
            }
        }
        for(j = 0; j < potentialCourseSections[i].lectureSections[0].labSections.length; j++)
        {
            if(j != lowestConflictLabIndex)
            {
                potentialCourseSections[i].lectureSections[0].labSections.splice(j, 1);
                lowestConflictLabIndex--;
                j--;
            }
        }
        
        document.write(potentialCourseSections[i].courseCode + " Lecture:");
        document.write(potentialCourseSections[i].lectureSections[0].lectureCode + " Tutorial:");
        
        if(potentialCourseSections[i].lectureSections[0].tutorialSections.length > 0)
        {
            
            document.write(potentialCourseSections[i].lectureSections[0].tutorialSections[0].tutorialCode);
        }
        if(potentialCourseSections[i].lectureSections[0].labSections.length > 0)
        {
            document.write(" Lab:" + potentialCourseSections[i].lectureSections[0].labSections[0].labCode);
        }
        document.write("<br>");
    }
    document.write("<br>");
}

function resolveConflicts(term, potentialCourses, lowPriorityCourses, potentialCourseSections, conflictCounterForSections)
{
    document.write("NOT YET IMPLEMENTED");
    document.write("<br>");
    document.write("<br>");
}

//Takes as parameters the current semester, whether summer courses are taken,
//a list of semester schedules, the list of incomplete courses, the list of complete courses,
//the list of potential courses, the list of low priority courses,the list of courses with their section
//and the list of conflict counters and changes the semester to the next one, adds and removes
//courses accordingly from the semester list, incomplete list and complete list,
//whilst reseting all the other lists in preparation for he next iteration
function prepNextIteration(term, summer, semesterCourses, incompleteCourses, completeCourses, potentialCourses, lowPriorityCourses, potentialCourseSections, conflictCounterForSections)
{
    while(true)
    {
        if(term == "fall")
        {
            term = "winter";
            break;
        }
        if(summer == true)
        {   
            if(term == "winter")
            {
                term = "summer";  
                break;
            }
            if(term == "summer")
            {
                term = "fall";  
                break;
            }
        }
        if(summer == false)
        {
            if(term == "winter")
            {
                term = "fall";  
                break;
            }
        }
    }

    for(i = 0; i < potentialCourseSections.length; i++)
    {
        semesterCourses.push(potentialCourseSections[i]);
        completeCourses.push(potentialCourseSections[i].courseCode);
        
        for(j = 0; j < incompleteCourses.length; j++)
        {
            if(potentialCourseSections[i].courseCode == incompleteCourses[j].courseCode)
            {
                incompleteCourses.splice(j, 1);
                break;
            }

        }
    }
    
    potentialCourses = [];
    lowPriorityCourses = [];
    potentialCourseSections = [];
    conflictCounterForSections = [];
    
    document.write("Courses taken this semester | ");
    for(i = 0; i < semesterCourses.length; i++)
    {
        document.write(semesterCourses[i].courseCode + " ");
    }
    document.write("<br>Courses completed so far | ");
    for(i = 0; i < completeCourses.length; i++)
    {
        document.write(completeCourses[i] + " ");
    }
    document.write("<br>Remaining courses required | ");
    for(i = 0; i < incompleteCourses.length; i++)
    {
        document.write(incompleteCourses[i].courseCode + " ");
    }
    document.write("<br>");
    document.write("<br>");
    document.write("Next term : " + term);
    document.write("<br>");
    document.write("<br>");
}

//Gets some of the variables required for the algorithm from user input
var term = "fall";
var summer = false;
var coursesPerSemester = 5;
var semesterCourses = [];
var incompleteCourses = [];
var completeCourses = ["engr201"];
var potentialCourses = [];
var lowPriorityCourses = [];
var potentialCourseSections = [];
var conflictCounterForSections = [];

//Algorithm
document.write("START<br>");
document.write("Current Term : " + term + "<br>");
document.write("<br>");

document.write("A. createIncompleteList()<br>");
createIncompleteList(courses, incompleteCourses);

document.write("B. removeCompletedCourses()<br>");
removeCompletedCourses(incompleteCourses, completeCourses);

//while(incompleteCourses.length > 0)
{
    document.write("C. addToPotentialList()<br>");
    addToPotentialList(term, courses, potentialCourses);

    document.write("D. remove400LevelCourses()<br>");
    remove400LevelCourses(potentialCourses, incompleteCourses);

    document.write("E. removeIncompletePrerequisiteCourses()<br>");
    removeIncompletePrerequisiteCourses(potentialCourses, completeCourses);

    document.write("F. sortPotentialList()<br>");
    sortPotentialList(potentialCourses, lowPriorityCourses);

    document.write("G. selectCoursesForSemester()<br>");
    selectCoursesForSemester(coursesPerSemester, semesterCourses, potentialCourses, lowPriorityCourses);

    document.write("H. initializeConflictCounterForSections()<br>");
    conflictCounterForSections = initializeConflictCounterForSections(term, potentialCourses);

    document.write("I. countTimeConflicts()<br>");
    countTimeConflicts(term, potentialCourses, conflictCounterForSections);

    document.write("J. addLowestConflictSections()<br>");
    addLowestConflictSections(potentialCourses, conflictCounterForSections, potentialCourseSections);

    document.write("K. resolveConflicts()<br>");
    resolveConflicts(term, potentialCourses, lowPriorityCourses, potentialCourseSections, conflictCounterForSections);

    document.write("L. prepNextIteration()<br>");
    prepNextIteration(term, summer, semesterCourses, incompleteCourses, completeCourses, potentialCourses, lowPriorityCourses, potentialCourseSections, conflictCounterForSections);
}
document.write("END");